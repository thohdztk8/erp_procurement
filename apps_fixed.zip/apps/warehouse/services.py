"""
WarehouseService: nhập kho IQC, cập nhật Inventory trong atomic transaction.
"""
import json
import logging
from decimal import Decimal

from django.db import transaction
from django.db.models import F

from core.utils.audit import write_audit_log
from core.utils.code_generator import generate_document_code

from .models import Inventory, StockReceipt, StockReceiptItem, StockIssue, StockIssueItem

logger = logging.getLogger("apps")


class WarehouseService:

    @staticmethod
    @transaction.atomic
    def create_receipt(user, validated_data: dict) -> StockReceipt:
        """
        Lập phiếu nhập kho + IQC.
        Cập nhật Inventory trong cùng transaction.
        """
        ipo_id = validated_data["ipo_id"]
        items_data = validated_data["items"]

        receipt_code = generate_document_code("WR", StockReceipt, "receipt_code")
        receipt = StockReceipt.objects.create(
            receipt_code=receipt_code,
            ipo_id=ipo_id,
            warehouse_keeper=user,
            delivery_note_ref=validated_data.get("delivery_note_ref"),
            note=validated_data.get("note"),
        )

        for item in items_data:
            qty_received = Decimal(str(item["qty_received"]))
            qty_passed = Decimal(str(item["qty_passed"]))
            qty_failed = Decimal(str(item["qty_failed"]))

            if qty_passed + qty_failed != qty_received:
                raise ValueError(
                    f"IQC error: qty_received ({qty_received}) ≠ "
                    f"qty_passed ({qty_passed}) + qty_failed ({qty_failed})"
                )

            photo_paths = item.get("photo_paths", [])
            if qty_failed > 0 and not photo_paths:
                raise ValueError("Bắt buộc có ảnh minh chứng khi qty_failed > 0.")

            material_id = item.get("material_id")

            # Nếu không truyền material_id, lấy từ IPOItem
            if not material_id:
                from apps.ipo.models import IPOItem
                ipo_item = IPOItem.objects.select_related("order_item__material").get(
                    ipo_item_id=item["ipo_item_id"]
                )
                material_id = ipo_item.order_item.material_id

            StockReceiptItem.objects.create(
                receipt=receipt,
                material_id=material_id,
                material_name_other=item.get("material_name_other"),
                qty_ordered=item["qty_ordered"],
                qty_received=qty_received,
                qty_passed=qty_passed,
                qty_failed=qty_failed,
                photo_paths=json.dumps(photo_paths, ensure_ascii=False) if photo_paths else None,
            )

            if material_id:
                # branch_id lấy từ IPO → Order → buyer.branch
                from apps.ipo.models import IPO
                ipo = IPO.objects.select_related("buyer__branch").get(ipo_id=ipo_id)
                branch_id = ipo.buyer.branch_id if ipo.buyer else None

                if branch_id:
                    inventory, _ = Inventory.objects.get_or_create(
                        branch_id=branch_id,
                        material_id=material_id,
                        defaults={"qty_on_hand": 0, "qty_available": 0, "qty_quarantine": 0}
                    )
                    Inventory.objects.filter(inventory_id=inventory.inventory_id).update(
                        qty_on_hand=F("qty_on_hand") + qty_passed,
                        qty_available=F("qty_available") + qty_passed,
                        qty_quarantine=F("qty_quarantine") + qty_failed,
                    )

        write_audit_log(
            user=user, event_type="CREATE",
            object_type="StockReceipts", object_id=str(receipt.receipt_id),
            new_values={"receipt_code": receipt_code, "ipo_id": ipo_id},
        )
        logger.info("Receipt %s created for IPO %d by %s", receipt_code, ipo_id, user.username)
        return receipt

    @staticmethod
    @transaction.atomic
    def issue_material(user, dept_id: int, material_id: int, qty: Decimal,
                       receiver_user_id: int, branch_id: int, purpose: str = "") -> StockIssue:
        """Xuất vật tư — trừ qty_available, tạo StockIssue + StockIssueItem."""
        inventory = Inventory.objects.select_for_update().get(
            material_id=material_id, branch_id=branch_id
        )
        if inventory.qty_available < qty:
            from rest_framework.exceptions import ValidationError
            raise ValidationError(
                f"Tồn kho không đủ. Sẵn có: {inventory.qty_available}, yêu cầu: {qty}."
            )

        issue_code = generate_document_code("WI", StockIssue, "issue_code")
        issue = StockIssue.objects.create(
            issue_code=issue_code,
            dept_id=dept_id,
            warehouse_keeper=user,
            receiver_id=receiver_user_id,
        )
        StockIssueItem.objects.create(
            issue=issue,
            material_id=material_id,
            qty_issued=qty,
        )

        Inventory.objects.filter(inventory_id=inventory.inventory_id).update(
            qty_on_hand=F("qty_on_hand") - qty,
            qty_available=F("qty_available") - qty,
        )

        write_audit_log(
            user=user, event_type="ISSUE",
            object_type="Inventory", object_id=str(inventory.inventory_id),
            new_values={"qty_issued": str(qty), "material_id": material_id},
        )
        return issue
