import json

from rest_framework import serializers

from .models import Inventory, ReturnOrder, ReturnOrderItem, StockIssue, StockIssueItem, StockReceipt, StockReceiptItem


class ReceiptItemCreateSerializer(serializers.Serializer):
    ipo_item_id = serializers.IntegerField()
    material_id = serializers.IntegerField(required=False, allow_null=True)
    material_name_other = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    qty_ordered = serializers.DecimalField(max_digits=18, decimal_places=4, min_value=0.0001)
    qty_received = serializers.DecimalField(max_digits=18, decimal_places=4, min_value=0.0001)
    qty_passed = serializers.DecimalField(max_digits=18, decimal_places=4, min_value=0)
    qty_failed = serializers.DecimalField(max_digits=18, decimal_places=4, min_value=0)
    photo_paths = serializers.ListField(
        child=serializers.CharField(max_length=500),
        required=False, default=list
    )

    def validate(self, attrs):
        if attrs["qty_passed"] + attrs["qty_failed"] != attrs["qty_received"]:
            raise serializers.ValidationError(
                f"qty_received phải bằng qty_passed + qty_failed."
            )
        if attrs["qty_failed"] > 0 and not attrs.get("photo_paths"):
            raise serializers.ValidationError(
                "Bắt buộc đính kèm ảnh minh chứng khi có hàng lỗi (qty_failed > 0)."
            )
        return attrs


class ReceiptCreateSerializer(serializers.Serializer):
    ipo_id = serializers.IntegerField()
    delivery_note_ref = serializers.CharField(required=False, allow_blank=True, max_length=100)
    note = serializers.CharField(required=False, allow_blank=True, max_length=500)
    items = ReceiptItemCreateSerializer(many=True, min_length=1)

    def validate_ipo_id(self, value):
        from apps.ipo.models import IPO
        try:
            IPO.objects.get(ipo_id=value, ipo_status="APPROVED", is_latest=True)
        except IPO.DoesNotExist:
            raise serializers.ValidationError("IPO không tồn tại hoặc chưa được phê duyệt.")
        return value


class ReceiptItemSerializer(serializers.ModelSerializer):
    photo_paths = serializers.SerializerMethodField()

    class Meta:
        model = StockReceiptItem
        fields = [
            "receipt_item_id", "material_id", "material_name_other",
            "qty_ordered", "qty_received", "qty_passed", "qty_failed",
            "photo_paths",
        ]

    def get_photo_paths(self, obj):
        if obj.photo_paths:
            try:
                return json.loads(obj.photo_paths)
            except (json.JSONDecodeError, TypeError):
                return []
        return []


class ReceiptSerializer(serializers.ModelSerializer):
    warehouse_keeper_name = serializers.CharField(source="warehouse_keeper.full_name", read_only=True)
    items = ReceiptItemSerializer(many=True, read_only=True)

    class Meta:
        model = StockReceipt
        fields = ["receipt_id", "receipt_code", "ipo_id", "warehouse_keeper_name",
                  "items", "received_at", "delivery_note_ref", "note"]


class InventorySerializer(serializers.ModelSerializer):
    material_code = serializers.CharField(source="material.material_code", read_only=True)
    material_name = serializers.CharField(source="material.material_name", read_only=True)
    uom = serializers.CharField(source="material.uom", read_only=True)
    branch_name = serializers.CharField(source="branch.branch_name", read_only=True)

    class Meta:
        model = Inventory
        fields = [
            "inventory_id", "branch_id", "branch_name",
            "material_id", "material_code", "material_name", "uom",
            "qty_on_hand", "qty_available", "qty_quarantine", "last_updated_at",
        ]


class ReturnOrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReturnOrderItem
        fields = ["return_item_id", "material_id", "qty_returned", "reason"]


class ReturnOrderSerializer(serializers.ModelSerializer):
    items = ReturnOrderItemSerializer(many=True, read_only=True)

    class Meta:
        model = ReturnOrder
        fields = [
            "return_id", "return_code", "receipt_id", "supplier_id",
            "return_status", "items", "created_at",
        ]


class StockIssueItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = StockIssueItem
        fields = ["issue_item_id", "material_id", "qty_issued", "quality_rating"]


class StockIssueSerializer(serializers.ModelSerializer):
    items = StockIssueItemSerializer(many=True, read_only=True)

    class Meta:
        model = StockIssue
        fields = [
            "issue_id", "issue_code", "pr_id", "dept_id",
            "warehouse_keeper_id", "receiver_id",
            "issued_at", "items",
        ]

# Backwards-compat alias
WarehouseReturnSerializer = ReturnOrderSerializer
