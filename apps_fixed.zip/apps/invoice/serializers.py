from rest_framework import serializers

from .models import (
    CreditNote, DebitNote, Invoice, InvoiceItem,
    InvoiceMatchingResult, PaymentRequest,
)


class InvoiceItemCreateSerializer(serializers.Serializer):
    ipo_item_id = serializers.IntegerField()
    qty_invoice = serializers.DecimalField(max_digits=18, decimal_places=4, min_value=0.0001)
    price_invoice = serializers.DecimalField(max_digits=18, decimal_places=2, min_value=0)


class InvoiceCreateSerializer(serializers.Serializer):
    invoice_number = serializers.CharField(max_length=50)
    ipo_id = serializers.IntegerField()
    supplier_id = serializers.IntegerField()
    invoice_date = serializers.DateTimeField()
    amount_before_tax = serializers.DecimalField(max_digits=18, decimal_places=2, min_value=0)
    tax_amount = serializers.DecimalField(max_digits=18, decimal_places=2, default=0, min_value=0)
    items = InvoiceItemCreateSerializer(many=True, min_length=1)

    def validate_invoice_number(self, value):
        # unique per (invoice_number, supplier) — dùng đơn giản hóa ở đây
        return value

    def validate_ipo_id(self, value):
        from apps.ipo.models import IPO
        try:
            IPO.objects.get(ipo_id=value, ipo_status="APPROVED", is_latest=True)
        except IPO.DoesNotExist:
            raise serializers.ValidationError("IPO không tồn tại hoặc chưa được phê duyệt.")
        return value


class InvoiceItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceItem
        fields = ["invoice_item_id", "ipo_item_id", "qty_invoice", "price_invoice"]


class InvoiceListSerializer(serializers.ModelSerializer):
    supplier_name = serializers.CharField(source="supplier.supplier_name", read_only=True)

    class Meta:
        model = Invoice
        fields = [
            "invoice_id", "invoice_number", "matching_status",
            "amount_before_tax", "tax_amount", "total_amount",
            "supplier_name", "invoice_date", "created_at",
        ]


class InvoiceDetailSerializer(serializers.ModelSerializer):
    supplier_name = serializers.CharField(source="supplier.supplier_name", read_only=True)
    items = InvoiceItemSerializer(many=True, read_only=True)

    class Meta:
        model = Invoice
        fields = [
            "invoice_id", "invoice_number", "matching_status",
            "amount_before_tax", "tax_amount", "total_amount",
            "invoice_pdf_path", "is_overridden", "override_note",
            "supplier_name", "invoice_date", "items", "created_at",
        ]


class InvoiceMatchingSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceMatchingResult
        fields = [
            "matching_id", "ipo_item_id", "receipt_item_id",
            "qty_invoice", "qty_received_passed", "qty_diff",
            "price_invoice", "price_ipo", "price_diff",
            "is_error", "log_details_json",
        ]

# Backwards-compat alias
ThreeWayMatchingSerializer = InvoiceMatchingSerializer


class OverrideSerializer(serializers.Serializer):
    override_note = serializers.CharField(min_length=10, max_length=500)


class PaymentRequestSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    applicant_name = serializers.CharField(source="applicant.full_name", read_only=True)

    class Meta:
        model = PaymentRequest
        fields = [
            "payment_req_id", "payment_req_code", "invoice_number",
            "requested_amount", "payment_deadline", "req_status",
            "applicant_name", "created_at",
        ]


class PaymentApproveSerializer(serializers.Serializer):
    payment_req_id = serializers.IntegerField()
    action = serializers.ChoiceField(choices=["APPROVE", "REJECT"])
    note = serializers.CharField(required=False, allow_blank=True, max_length=500)
