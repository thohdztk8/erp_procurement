"""
MatchingService: đối soát 3 chiều (Invoice × IPO × StockReceipt).
PaymentService: tạo và duyệt yêu cầu thanh toán.
"""
import logging
from decimal import Decimal

from django.db import transaction

from core.utils.audit import write_audit_log
from core.utils.code_generator import generate_document_code

from .models import (
    CreditNote, DebitNote, Invoice, InvoiceItem,
    InvoiceMatchingResult, PaymentRequest,
)

logger = logging.getLogger("apps")


class MatchingService:

    @staticmethod
    @transaction.atomic
    def create_invoice(user, validated_data: dict) -> Invoice:
        """Tạo hóa đơn đỏ từ NCC."""
        items_data = validated_data.pop("items")
        # Tính total_amount từ amount_before_tax + tax_amount
        amount_before_tax = Decimal(str(validated_data["amount_before_tax"]))
        tax_amount = Decimal(str(validated_data.get("tax_amount", 0)))
        validated_data["total_amount"] = amount_before_tax + tax_amount

        invoice = Invoice.objects.create(**validated_data)

        InvoiceItem.objects.bulk_create([
            InvoiceItem(
                invoice=invoice,
                ipo_item_id=item["ipo_item_id"],
                qty_invoice=item["qty_invoice"],
                price_invoice=item["price_invoice"],
            )
            for item in items_data
        ])

        write_audit_log(
            user=user, event_type="CREATE",
            object_type="Invoices", object_id=str(invoice.invoice_id),
            new_values={"invoice_number": invoice.invoice_number, "total": str(invoice.total_amount)},
        )
        return invoice

    @staticmethod
    @transaction.atomic
    def run_three_way_matching(invoice: Invoice, user) -> list:
        """
        Đối soát 3 chiều — tạo nhiều InvoiceMatchingResult (1 per InvoiceItem).
        """
        from apps.warehouse.models import StockReceiptItem
        from django.db.models import Sum

        has_error = False
        results = []

        for inv_item in invoice.items.select_related("ipo_item"):
            ipo_item = inv_item.ipo_item
            price_ipo = ipo_item.unit_price

            qty_passed_agg = (
                StockReceiptItem.objects.filter(material_id=ipo_item.order_item.material_id)
                .aggregate(total=Sum("qty_passed"))["total"]
            ) or Decimal("0")

            qty_diff = inv_item.qty_invoice - qty_passed_agg
            price_diff = inv_item.price_invoice - price_ipo
            item_error = (qty_diff != 0) or (price_diff != 0)

            if item_error:
                has_error = True

            receipt_item = StockReceiptItem.objects.filter(
                material_id=ipo_item.order_item.material_id
            ).first()

            result, _ = InvoiceMatchingResult.objects.update_or_create(
                invoice=invoice,
                ipo_item=ipo_item,
                defaults={
                    "receipt_item": receipt_item,
                    "qty_invoice": inv_item.qty_invoice,
                    "qty_received_passed": qty_passed_agg,
                    "qty_diff": qty_diff,
                    "price_invoice": inv_item.price_invoice,
                    "price_ipo": price_ipo,
                    "price_diff": price_diff,
                    "is_error": item_error,
                },
            )
            results.append(result)

        invoice.matching_status = "MISMATCHED" if has_error else "MATCHED"
        invoice.save(update_fields=["matching_status"])

        write_audit_log(
            user=user, event_type="MATCHING",
            object_type="Invoices", object_id=str(invoice.invoice_id),
            new_values={"is_error": has_error, "matching_status": invoice.matching_status},
        )
        logger.info("3-way matching done: invoice=%s error=%s", invoice.invoice_number, has_error)
        return results

    @staticmethod
    @transaction.atomic
    def override_matching(invoice: Invoice, user, override_note: str) -> Invoice:
        """Ban Giám đốc override sai lệch — lưu vào bảng Invoices."""
        if invoice.matching_status != "MISMATCHED":
            from rest_framework.exceptions import ValidationError
            raise ValidationError("Hóa đơn không ở trạng thái MISMATCHED để override.")

        invoice.is_overridden = True
        invoice.override_note = override_note
        invoice.override_by = user
        invoice.matching_status = "MATCHED"
        invoice.save(update_fields=["is_overridden", "override_note", "override_by_id", "matching_status"])

        write_audit_log(
            user=user, event_type="OVERRIDE_MATCHING",
            object_type="Invoices", object_id=str(invoice.invoice_id),
            new_values={"override_note": override_note, "overridden_by": user.username},
        )
        return invoice


class PaymentService:

    @staticmethod
    @transaction.atomic
    def create_payment_request(user, invoice: Invoice) -> PaymentRequest:
        if invoice.matching_status not in ("MATCHED",):
            from rest_framework.exceptions import ValidationError
            raise ValidationError("Chỉ tạo yêu cầu thanh toán cho hóa đơn đã đối soát khớp.")

        from django.utils import timezone
        from datetime import timedelta

        payment_req_code = generate_document_code("PAY", PaymentRequest, "payment_req_code")

        payment, created = PaymentRequest.objects.get_or_create(
            invoice=invoice,
            defaults={
                "payment_req_code": payment_req_code,
                "requested_amount": invoice.total_amount,
                "req_status": "PENDING",
                "applicant": user,
                "payment_deadline": timezone.now() + timedelta(days=30),
            },
        )
        if not created:
            from rest_framework.exceptions import ValidationError
            raise ValidationError("Yêu cầu thanh toán đã tồn tại cho hóa đơn này.")

        write_audit_log(
            user=user, event_type="CREATE",
            object_type="PaymentRequests", object_id=str(payment.payment_req_id),
            new_values={"invoice_id": invoice.invoice_id, "amount": str(payment.requested_amount)},
        )
        return payment

    @staticmethod
    @transaction.atomic
    def approve_payment(user, payment: PaymentRequest, action: str, note: str = "") -> PaymentRequest:
        payment.req_status = "APPROVED" if action == "APPROVE" else "REJECTED"
        payment.save(update_fields=["req_status"])

        if action == "APPROVE":
            payment.invoice.matching_status = "PAID"
            payment.invoice.save(update_fields=["matching_status"])

        write_audit_log(
            user=user, event_type=action,
            object_type="PaymentRequests", object_id=str(payment.payment_req_id),
            new_values={"action": action, "note": note},
        )
        return payment
