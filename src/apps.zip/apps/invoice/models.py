"""
Module 8: Invoice, 3-Way Matching & Payment.
Bảng: Invoices, InvoiceItems, ThreeWayMatchingResults,
      PaymentRequests, CreditNotes, DebitNotes,
      SupplierEvaluations, SupplierEvaluationCriteria
"""
from django.db import models

from apps.authentication.models import User
from apps.ipo.models import IPO, IPOItem
from apps.master_data.models import Supplier
from apps.warehouse.models import WarehouseReceiptItem


class Invoice(models.Model):
    STATUS_CHOICES = [
        ("PENDING", "Chờ đối soát"),
        ("MATCHED", "Khớp"),
        ("MISMATCHED", "Sai lệch"),
        ("PAID", "Đã thanh toán"),
    ]

    invoice_id = models.AutoField(primary_key=True)
    invoice_code = models.CharField(max_length=50, unique=True)   # Số hóa đơn đỏ
    ipo = models.ForeignKey(
        IPO, on_delete=models.PROTECT, db_column="ipo_id", related_name="invoices"
    )
    supplier = models.ForeignKey(
        Supplier, on_delete=models.PROTECT, db_column="supplier_id"
    )
    invoice_date = models.DateField()
    total_invoice_amount = models.DecimalField(max_digits=18, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    invoice_status = models.CharField(max_length=30, choices=STATUS_CHOICES, default="PENDING")
    created_by = models.ForeignKey(
        User, on_delete=models.PROTECT, db_column="created_by_user_id"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Invoices"

    def __str__(self):
        return self.invoice_code


class InvoiceItem(models.Model):
    invoice_item_id = models.AutoField(primary_key=True)
    invoice = models.ForeignKey(
        Invoice, on_delete=models.CASCADE, db_column="invoice_id", related_name="items"
    )
    ipo_item = models.ForeignKey(
        IPOItem, on_delete=models.PROTECT, db_column="ipo_item_id"
    )
    qty_invoice = models.DecimalField(max_digits=18, decimal_places=4)
    price_invoice = models.DecimalField(max_digits=18, decimal_places=2)

    class Meta:
        db_table = "InvoiceItems"


class ThreeWayMatchingResult(models.Model):
    matching_id = models.AutoField(primary_key=True)
    invoice = models.OneToOneField(
        Invoice, on_delete=models.CASCADE,
        db_column="invoice_id", related_name="matching_result"
    )
    invoice_item = models.ForeignKey(
        InvoiceItem, on_delete=models.CASCADE, db_column="invoice_item_id"
    )
    receipt_item = models.ForeignKey(
        WarehouseReceiptItem, on_delete=models.PROTECT, db_column="receipt_item_id"
    )
    # Đối soát số lượng
    qty_invoice = models.DecimalField(max_digits=18, decimal_places=4)
    qty_received_passed = models.DecimalField(max_digits=18, decimal_places=4)
    qty_diff = models.DecimalField(max_digits=18, decimal_places=4)        # = qty_invoice - qty_received_passed
    # Đối soát đơn giá
    price_invoice = models.DecimalField(max_digits=18, decimal_places=2)
    price_ipo = models.DecimalField(max_digits=18, decimal_places=2)
    price_diff = models.DecimalField(max_digits=18, decimal_places=2)      # = price_invoice - price_ipo
    # Kết quả
    is_error = models.BooleanField(default=False)
    is_overridden = models.BooleanField(default=False)
    override_note = models.CharField(max_length=500, null=True, blank=True)
    overridden_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        db_column="overridden_by_user_id"
    )
    matched_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "ThreeWayMatchingResults"


class PaymentRequest(models.Model):
    STATUS_CHOICES = [
        ("PENDING", "Chờ duyệt"),
        ("APPROVED", "Đã duyệt"),
        ("PAID", "Đã thanh toán"),
        ("REJECTED", "Từ chối"),
    ]

    payment_id = models.AutoField(primary_key=True)
    invoice = models.OneToOneField(
        Invoice, on_delete=models.PROTECT, db_column="invoice_id", related_name="payment"
    )
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    payment_status = models.CharField(max_length=30, choices=STATUS_CHOICES, default="PENDING")
    requested_by = models.ForeignKey(
        User, on_delete=models.PROTECT, db_column="requested_by_user_id"
    )
    approved_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        db_column="approved_by_user_id", related_name="approved_payments"
    )
    payment_date = models.DateField(null=True, blank=True)
    note = models.CharField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "PaymentRequests"


class CreditNote(models.Model):
    credit_id = models.AutoField(primary_key=True)
    credit_code = models.CharField(max_length=50, unique=True)
    invoice = models.ForeignKey(
        Invoice, on_delete=models.PROTECT, db_column="invoice_id", related_name="credit_notes"
    )
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, db_column="supplier_id")
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    reason = models.CharField(max_length=500)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, db_column="created_by_user_id")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "CreditNotes"


class DebitNote(models.Model):
    debit_id = models.AutoField(primary_key=True)
    debit_code = models.CharField(max_length=50, unique=True)
    invoice = models.ForeignKey(
        Invoice, on_delete=models.PROTECT, db_column="invoice_id", related_name="debit_notes"
    )
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, db_column="supplier_id")
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    reason = models.CharField(max_length=500)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, db_column="created_by_user_id")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "DebitNotes"


class SupplierEvaluation(models.Model):
    evaluation_id = models.AutoField(primary_key=True)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, db_column="supplier_id")
    evaluator = models.ForeignKey(User, on_delete=models.PROTECT, db_column="evaluator_user_id")
    period = models.CharField(max_length=20)          # Ví dụ: "2026-Q1"
    total_score = models.DecimalField(max_digits=5, decimal_places=2)
    notes = models.CharField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "SupplierEvaluations"
        unique_together = ("supplier", "period")


class SupplierEvaluationCriteria(models.Model):
    criteria_id = models.AutoField(primary_key=True)
    evaluation = models.ForeignKey(
        SupplierEvaluation, on_delete=models.CASCADE,
        db_column="evaluation_id", related_name="criteria"
    )
    criteria_name = models.CharField(max_length=100)
    score = models.DecimalField(max_digits=5, decimal_places=2)
    weight = models.DecimalField(max_digits=5, decimal_places=2, default=1.0)
    notes = models.CharField(max_length=300, null=True, blank=True)

    class Meta:
        db_table = "SupplierEvaluationCriteria"
