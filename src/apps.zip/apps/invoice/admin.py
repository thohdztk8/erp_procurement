from django.contrib import admin

from .models import (
    CreditNote, DebitNote, Invoice, InvoiceItem,
    PaymentRequest, SupplierEvaluation, ThreeWayMatchingResult,
)


class InvoiceItemInline(admin.TabularInline):
    model = InvoiceItem
    extra = 0


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ["invoice_code", "supplier", "invoice_status", "total_invoice_amount", "invoice_date"]
    list_filter = ["invoice_status", "supplier"]
    search_fields = ["invoice_code"]
    readonly_fields = ["created_at"]
    inlines = [InvoiceItemInline]


@admin.register(ThreeWayMatchingResult)
class ThreeWayMatchingAdmin(admin.ModelAdmin):
    list_display = ["matching_id", "invoice", "is_error", "is_overridden", "matched_at"]
    list_filter = ["is_error", "is_overridden"]
    readonly_fields = ["matched_at"]


@admin.register(PaymentRequest)
class PaymentRequestAdmin(admin.ModelAdmin):
    list_display = ["payment_id", "invoice", "amount", "payment_status", "payment_date"]
    list_filter = ["payment_status"]


@admin.register(CreditNote)
class CreditNoteAdmin(admin.ModelAdmin):
    list_display = ["credit_code", "invoice", "supplier", "amount", "created_at"]


@admin.register(DebitNote)
class DebitNoteAdmin(admin.ModelAdmin):
    list_display = ["debit_code", "invoice", "supplier", "amount", "created_at"]


@admin.register(SupplierEvaluation)
class SupplierEvaluationAdmin(admin.ModelAdmin):
    list_display = ["supplier", "period", "total_score", "evaluator", "created_at"]
    list_filter = ["period"]
