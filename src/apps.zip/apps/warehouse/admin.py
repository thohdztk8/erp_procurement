from django.contrib import admin

from .models import Inventory, WarehouseIssue, WarehouseReceipt, WarehouseReceiptItem, WarehouseReturn


class ReceiptItemInline(admin.TabularInline):
    model = WarehouseReceiptItem
    extra = 0
    readonly_fields = ["qty_received", "qty_passed", "qty_failed"]


@admin.register(WarehouseReceipt)
class WarehouseReceiptAdmin(admin.ModelAdmin):
    list_display = ["receipt_code", "ipo", "receiver", "receipt_date"]
    search_fields = ["receipt_code"]
    inlines = [ReceiptItemInline]


@admin.register(Inventory)
class InventoryAdmin(admin.ModelAdmin):
    list_display = ["material", "qty_available", "qty_quarantine", "last_updated"]
    search_fields = ["material__material_code", "material__material_name"]
    readonly_fields = ["last_updated"]


@admin.register(WarehouseIssue)
class WarehouseIssueAdmin(admin.ModelAdmin):
    list_display = ["issue_code", "material", "qty_issued", "issued_by", "issue_date"]
    search_fields = ["issue_code"]


@admin.register(WarehouseReturn)
class WarehouseReturnAdmin(admin.ModelAdmin):
    list_display = ["return_code", "supplier", "qty_returned", "return_status", "created_at"]
    list_filter = ["return_status"]
