"""
Module 7: Warehouse — IQC, Nhận/Xuất/Trả hàng, Inventory.
Bảng: WarehouseReceipts, WarehouseReceiptItems, Inventory,
      WarehouseIssues, WarehouseReturns
"""
from django.db import models

from apps.authentication.models import User
from apps.ipo.models import IPO, IPOItem
from apps.master_data.models import Material, Supplier


class WarehouseReceipt(models.Model):
    receipt_id = models.AutoField(primary_key=True)
    receipt_code = models.CharField(max_length=30, unique=True)
    ipo = models.ForeignKey(
        IPO, on_delete=models.PROTECT, db_column="ipo_id", related_name="receipts"
    )
    receiver = models.ForeignKey(
        User, on_delete=models.PROTECT, db_column="receiver_user_id"
    )
    receipt_date = models.DateTimeField(auto_now_add=True)
    notes = models.CharField(max_length=500, null=True, blank=True)

    class Meta:
        db_table = "WarehouseReceipts"

    def __str__(self):
        return self.receipt_code


class WarehouseReceiptItem(models.Model):
    receipt_item_id = models.AutoField(primary_key=True)
    receipt = models.ForeignKey(
        WarehouseReceipt, on_delete=models.CASCADE,
        db_column="receipt_id", related_name="items"
    )
    ipo_item = models.ForeignKey(
        IPOItem, on_delete=models.PROTECT, db_column="ipo_item_id"
    )
    qty_received = models.DecimalField(max_digits=18, decimal_places=4)
    qty_passed = models.DecimalField(max_digits=18, decimal_places=4)    # Hàng đạt IQC
    qty_failed = models.DecimalField(max_digits=18, decimal_places=4)    # Hàng lỗi IQC
    photo_paths = models.TextField(null=True, blank=True)                # JSON array đường dẫn ảnh
    failure_reason = models.CharField(max_length=500, null=True, blank=True)

    class Meta:
        db_table = "WarehouseReceiptItems"

    def clean(self):
        from django.core.exceptions import ValidationError
        # Phương trình cân bằng: qty_received = qty_passed + qty_failed
        if self.qty_passed + self.qty_failed != self.qty_received:
            raise ValidationError(
                f"qty_received ({self.qty_received}) phải bằng "
                f"qty_passed ({self.qty_passed}) + qty_failed ({self.qty_failed})."
            )
        if self.qty_failed > 0 and not self.photo_paths:
            raise ValidationError("Bắt buộc đính kèm ảnh minh chứng khi có hàng lỗi (qty_failed > 0).")


class Inventory(models.Model):
    inventory_id = models.AutoField(primary_key=True)
    material = models.OneToOneField(
        Material, on_delete=models.PROTECT, db_column="material_id"
    )
    qty_available = models.DecimalField(max_digits=18, decimal_places=4, default=0)   # Hàng đạt, sẵn sàng dùng
    qty_quarantine = models.DecimalField(max_digits=18, decimal_places=4, default=0)  # Hàng lỗi, cách ly
    last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Inventory"

    def __str__(self):
        return f"Inventory [{self.material.material_code}]"


class WarehouseIssue(models.Model):
    issue_id = models.AutoField(primary_key=True)
    issue_code = models.CharField(max_length=30, unique=True)
    material = models.ForeignKey(
        Material, on_delete=models.PROTECT, db_column="material_id"
    )
    qty_issued = models.DecimalField(max_digits=18, decimal_places=4)
    issued_to = models.ForeignKey(
        User, on_delete=models.PROTECT, db_column="issued_to_user_id"
    )
    issued_by = models.ForeignKey(
        User, on_delete=models.PROTECT, db_column="issued_by_user_id",
        related_name="issued_by_set"
    )
    issue_date = models.DateTimeField(auto_now_add=True)
    purpose = models.CharField(max_length=300, null=True, blank=True)

    class Meta:
        db_table = "WarehouseIssues"


class WarehouseReturn(models.Model):
    STATUS_CHOICES = [
        ("DRAFT", "Nháp"),
        ("SENT", "Đã gửi NCC"),
        ("RESOLVED", "Đã xử lý"),
    ]

    return_id = models.AutoField(primary_key=True)
    return_code = models.CharField(max_length=30, unique=True)
    receipt_item = models.ForeignKey(
        WarehouseReceiptItem, on_delete=models.PROTECT, db_column="receipt_item_id"
    )
    supplier = models.ForeignKey(
        Supplier, on_delete=models.PROTECT, db_column="supplier_id"
    )
    qty_returned = models.DecimalField(max_digits=18, decimal_places=4)
    return_reason = models.CharField(max_length=500)
    return_status = models.CharField(max_length=30, choices=STATUS_CHOICES, default="DRAFT")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "WarehouseReturns"
